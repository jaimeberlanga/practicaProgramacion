/**
 * puntoEntrada es la capa que contiene la clase Principal.java
 */
package puntoEntrada;