package puntoEntrada;
import presentacion.interfazUsuario;
/**
 *Crea la clase pública "Principal"
 */
public class Principal{
	public static void main(String[] args){
		interfazUsuario.ejecutar(args);
	}
}
