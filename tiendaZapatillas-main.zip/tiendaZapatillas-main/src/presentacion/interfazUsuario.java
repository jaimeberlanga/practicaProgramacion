package presentacion;

import java.util.ArrayList;

import negocio.Tienda;
import negocio.Zapatilla;

/**
 *
 */
public class interfazUsuario{
	private static String negrita = "\u001B[1m";
	private static String normal = "\033[0m";
	private static String rojo = "\u001B[31m";
	private static String blanco = "\u001B[37m";
	public static void ejecutar(String[] instruccion){

		/**
		 * las instrucciones son los atributos
		 * instruccion 0 es añadir, 1 es la marca, 2 el color...
		 * equalsIgnoreCase sirve para ignorar las mayusculas
		 */

		/**
		 * el método annadir (añadir) agrega la zapatilla recién creada a la tienda
		 * el método ayuda muestra los comandos que hay que ejecutar para añadir y mostrar zapatillas
		 * el método borrar elimina una zapatilla específica de la tienda
		 * el método modificar, modifica una zapatilla específica de la tienda y actualiza la lista de zapatillas
		 */

		Tienda tienda = new Tienda();
		if (instruccion.length == 0){
			ayuda();
		}
		else if (instruccion[0].equalsIgnoreCase("mostrar") && instruccion.length == 1){
			mostrarZapatilla(tienda);

		}else if  (instruccion[0].equalsIgnoreCase("añadir") && instruccion.length == 4){
			int instruccion3 = Integer.parseInt(instruccion[3]);
			Zapatilla zapatilla = new Zapatilla (instruccion[1], instruccion [2], Integer.parseInt(instruccion[3]));
			tienda.annadir(zapatilla);

		}else if (instruccion[0].equalsIgnoreCase("borrar") && instruccion.length == 2){
			Zapatilla zapatilla = new Zapatilla(Integer.parseInt(instruccion[1]));
			tienda.borrar(zapatilla);

		}else if (instruccion[0].equalsIgnoreCase("modificar") && instruccion.length == 5){
			int instruccion1 = Integer.parseInt(instruccion[1]);
			int instruccion5 = Integer.parseInt(instruccion[4]);
			Zapatilla zapatillaModificada = new Zapatilla(Integer.parseInt(instruccion[1]), instruccion[2], instruccion[3], Integer.parseInt(instruccion[4]));

		       tienda.modificar(zapatillaModificada);
		}else if (instruccion[0].equalsIgnoreCase("ayuda") && instruccion.length == 1){
			ayuda();
		}else{ System.out.println(rojo + "El formato utilizado en la entrada es incorrecto" + blanco);
			ayuda();
		}

	}

	/**
	 * El método `mostrarZapatilla` recibe un objeto de tipo `Tienda` como argumento y muestra en la consola
	 * todas las zapatillas disponibles en esa tienda. Para hacerlo, primero obtiene la lista de zapatillas
	 * de la tienda utilizando el método `getZapatillasTienda()` de la clase `Tienda`.
	 * Luego, itera a través de esta lista de zapatillas y muestra cada una de ellas en la consola
	 * utilizando `System.out.println(zapatilla)`, donde `zapatilla` es una instancia de la clase `Zapatilla`.
	 */
	private static void mostrarZapatilla(Tienda tienda){
	ArrayList<Zapatilla> listaZapatilla = tienda.getZapatillasTienda();
	for(Zapatilla zapatilla : listaZapatilla){
	System.out.println(zapatilla);
	}
}

private static void ayuda(){
	System.out.println("\n"+negrita+"DESCRIPCIÓN"+normal);
	System.out.println("\tEsta aplicación ofrece las siguientes funcionalidades:\n\n" + 
			"\t- Permite añadir una nueva zapatilla a la tienda\n" + 
			"\t- Permite mostrar las zapatillas de la tienda\n" +
			"\t- Permite borrar las zapatillas de la tienda\n" +
			"\t- Permite modificar las zapatillas de la tienda");
	System.out.println(negrita+"FORMATO"+normal);
	System.out.println("\tPara añadir una nueva zapatilla, se escribe:\n");
	System.out.println("\t\t" + negrita+ "java -cp bin puntoEntrada.Principal añadir <marca> <color> <talla>" + normal +"\n");
	System.out.println("\tPara mostrar las zapatillas de la tienda, se teclea:\n");
	System.out.println("\t\t" + negrita + "java -cp bin puntoEntrada.Principal mostrar" + normal + "\n");
	System.out.println("\tPara mostrar esta ayuda, se escribe:\n");
	System.out.println("\t\t" + negrita +"java -cp bin puntoEntrada.Principal ayuda" + normal + "\n");
	System.out.println("\tPara borrar las zapatillas de la tienda, se teclea:\n");
	System.out.println("\t\t" + negrita+ "java -cp bin puntoEntrada.Principal borrar <id>" + normal + "\n" );
	System.out.println("\tPara modificar las zapatillas de la tienda, se teclea:\n");
	System.out.println("\t\t" + negrita+ "java -cp bin puntoEntrada.Principal modificar <id> <marca> <color> <talla>" + normal + "\n" );
	System.out.println(negrita+"EJEMPLOS"+normal);
	System.out.println("\tEjemplo 1\n");
	System.out.println("\t\t" + negrita +"java -cp bin puntoEntrada.Principal añadir adidas azul 42" + normal + "\n");
	System.out.println("\tEjemplo 2\n");
	System.out.println("\t\t" + negrita +"java -cp bin puntoEntrada.Principal borrar 2" + normal + "\n");
	System.out.println("\tEjemplo 3\n");
	System.out.println("\t\t" + negrita + "java -cp bin puntoEntrada.Principal mostrar" + normal+ "\n");
	System.out.println("\tEjemplo 4\n");
	System.out.println("\t\t" + negrita + "java -cp bin puntoEntrada.Principal ayuda" + normal + "\n");
	System.out.println("\tEjemplo 5\n");
	System.out.println("\t\t" + negrita +"java -cp bin puntoEntrada.Principal modificar 1 adidas azul 42" + normal + "\n");


}
}
