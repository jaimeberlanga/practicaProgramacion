/**
 * negocio es la capa que contiene la lógica de la aplicación
 */
package negocio;