package negocio;

/**
 * crea la clase Zapatilla
 */
public class Zapatilla {
    private int id;
    private String marca;
    private String color;
    private int talla;

    /**
     * Constructor que inicializa una zapatilla con un ID, marca, color y talla específicos.
     *
     * @param id    El ID de la zapatilla.
     * @param marca La marca de la zapatilla.
     * @param color El color de la zapatilla.
     * @param talla La talla de la zapatilla.
     */
    public Zapatilla(int id, String marca, String color, int talla) {
        this.id = id;
        this.marca = marca;
        this.color = color;
        this.talla = talla;
    }

    /**
     * Constructor que inicializa una zapatilla con una marca, color y talla específicos.
     *
     * @param marca La marca de la zapatilla.
     * @param color El color de la zapatilla.
     * @param talla La talla de la zapatilla.
     */
    public Zapatilla(String marca, String color, int talla) {
        this.marca = marca;
        this.color = color;
        this.talla = talla;
    }
    /**
     * Constructor que inicializa una zapatilla con un ID específico.
     *
     * @param id El ID de la zapatilla.
     */
    public Zapatilla(int id){
        this.id = id;
    }
    @Override
    /**
     * este método compara si el id que estás dando es igual que el id que tiene de la zapatilla
     */
    public boolean equals(Object obj){
        Zapatilla zap = (Zapatilla) obj;
        return id == zap.id;
    }

    /**
     * @return devuelve los atributos de la zapatilla: el id, la marca, el color y la talla.
     * Estos atributos se han añadido anteriormente.
     */
    @Override
    public String toString() {
        return getId() + "," + getMarca() + "," + getColor() + "," + getTalla();
    }

    /**
     * Obtiene el ID de la zapatilla.
     *
     * @return El ID de la zapatilla.
     */
    public int getId() {return id;}
    /**
     * Obtiene la marca de la zapatilla.
     *
     * @return La marca de la zapatilla.
     */
    public String getMarca() {return marca;}
    /**
     * Obtiene el color de la zapatilla.
     *
     * @return El color de la zapatilla.
     */
    public String getColor() {
        return color;
    }

    /**
     * Obtiene la talla de la zapatilla.
     *
     * @return La talla de la zapatilla.
     */
    public int getTalla() {
        return talla;
    }

    /**
     * Establece el ID de la zapatilla.
     *
     * @param id El nuevo ID de la zapatilla.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Establece la marca de la zapatilla.
     *
     * @param marca La nueva marca de la zapatilla.
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Establece el color de la zapatilla.
     *
     * @param color El nuevo color de la zapatilla.
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * Establece la talla de la zapatilla.
     *
     * @param talla La nueva talla de la zapatilla.
     */
    public void setTalla(int talla) {
        this.talla = talla;
    }
}

