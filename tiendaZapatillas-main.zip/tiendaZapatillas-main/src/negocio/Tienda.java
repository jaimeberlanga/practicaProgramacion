package negocio;

import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;
import java.io.File;
import java.util.Scanner;

/**
 * Define la clase Tienda
 */
public class Tienda{
	private ArrayList <Zapatilla> zapatillasTienda = new ArrayList <>();

	public Tienda(){
		cargarZapatillas();
	}

	/**
	 * Añade una zapatilla a la tienda, asignándole un ID único.
	 * Si la lista de zapatillas de la tienda no está vacía, el nuevo ID será
	 * el ID de la última zapatilla en la lista más 1. Si la lista está vacía,
	 * el ID se establecerá en 1. Después de añadir la zapatilla, se actualiza
	 * la persistencia de las zapatillas en la tienda.
	 *
	 * @param zapatilla La zapatilla que se va a añadir a la tienda.
	 */
	public void annadir (Zapatilla zapatilla){
		if (!zapatillasTienda.isEmpty()) zapatilla.setId(zapatillasTienda.get(zapatillasTienda.size() - 1).getId()+1);
		else zapatilla.setId(1);
		zapatillasTienda.add(zapatilla);
		volcarZapatillasTienda();
	}
	/**
	 * Elimina una zapatilla de la tienda y actualiza la persistencia de las zapatillas en la tienda.
	 *
	 * @param zapatilla La zapatilla que se va a eliminar de la tienda.
	 */

	public void borrar(Zapatilla zapatilla){
		zapatillasTienda.remove(zapatilla);
		volcarZapatillasTienda();
	}
	/**
	 * Obtiene la lista de zapatillas actualmente en la tienda.
	 *
	 * @return La lista de zapatillas en la tienda.
	 */

	public ArrayList<Zapatilla> getZapatillasTienda(){
		return zapatillasTienda;
	}
	private void volcarZapatillasTienda(){
	try{
		FileWriter fw = new FileWriter("tienda.csv");
		for(Zapatilla zapatilla : zapatillasTienda){
			fw.write(zapatilla.getId() + "," +
					zapatilla.getMarca() + "," +
					zapatilla.getColor() + "," +
					zapatilla.getTalla() + "\n"); 
		}
		fw.close();
	}catch(IOException ex){
		System.err.println(ex);
	}
	}
	private void cargarZapatillas(){
		try{
			File fichero = new File("tienda.csv");
			/**
			 * Crea el fichero si no existe
			 */
			fichero.createNewFile();
			Scanner sc = new Scanner(fichero);
			sc.useDelimiter(",|\n");
			while(sc.hasNext()){
				Zapatilla zapatilla = new Zapatilla(Integer.parseInt(sc.next()),
								sc.next(),
								sc.next(),
								Integer.parseInt(sc.next()));
			zapatillasTienda.add(zapatilla);

			}
			sc.close();
		}catch(IOException ex){
			System.err.println("No hay zapatillas inscritas");
		}
	}
	/**
	 * Modifica una zapatilla existente de la lista de zapatillas y guarda los cambios en el archivo.
	 *@param zapatillaModificada: la zapatilla modificada a guardar.
	 */
	public void modificar(Zapatilla zapatillaModificada){
		for (Zapatilla zapatilla: zapatillasTienda){
			if (zapatilla.getId() == zapatillaModificada.getId()){
				zapatilla.setMarca(zapatillaModificada.getMarca());
				zapatilla.setColor(zapatillaModificada.getColor());
				zapatilla.setTalla(zapatillaModificada.getTalla());
				volcarZapatillasTienda();
				return;
			}
		}
	}
}
