# tiendaZapatillas
Este programa está creado con el propósito de funcionar como un catálogo, en el que el usuario pueda incluir y poder ver impreso por pantalla las zapatillas que este haya añadido, teniendo estos diversos atributos.
## Instalación:
Para instalar el programa debe escribir `make jar`
## Ejecución:
Para ejecutar debe escribir `java -jar aplicacionZapatillas.jar añadir <marca><color><talla>`

Por ejemplo: `java -jar aplicacionZapatillas.jar añadir adidas azul 42`
## Suprime los directorios bin y html, elimina los ficheros .jar, los .class y .txt.
`make limpiar`
## Crea el directorio bin y almacena los .class que ha compilado durante la ejecucion del make:
`make compilar`
## Crea el jar
`make jar`
## Generación del html:
`make javadoc`
## Estructura interna de la aplicación:
### La aplicación esta estructurada en 2 partes: negocio y presentacion
En el package negocio se encuentra la clase Tienda, la cual se encarga de gestionar la información de zapatillas de una tienda. También se encuentra la clase Zapatilla que representa un objeto de zapatilla.

En el package presentacion se encuentra la clase pública interfazUsuario que es la clase principal que contiene la lógica para interactuar con el programa.

![image](https://github.com/manutabasco/tiendaZapatillas/assets/145661237/a7f1ffde-d132-4351-8f3f-dc080e7360a6)

## Licencia
**Copyright** [2023] [Manuel Tabasco García]

Proyecto licenciado bajo la [Licencia apache 2.0]. Consulte el  archivo [LICENSE](LICENSE.txt) para obtener más detalles.
